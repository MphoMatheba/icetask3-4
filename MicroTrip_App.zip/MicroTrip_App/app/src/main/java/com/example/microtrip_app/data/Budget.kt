package com.example.microtrip_app.data


data class Budget(
    val transport: Int,
    val food: Int,
    val entry: Int,
    val misc: Int
)