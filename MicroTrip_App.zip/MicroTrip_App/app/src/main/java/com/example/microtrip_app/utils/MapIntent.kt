package com.example.microtrip_app.utils
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.microtrips.data.Location

fun openInGoogleMaps(context: Context, location: Location) {
    val uri = Uri.parse("geo:${location.latitude},${location.longitude}")
    val intent = Intent(Intent.ACTION_VIEW, uri)
    context.startActivity(intent)
}