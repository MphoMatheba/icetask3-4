package com.example.microtrip_app.data
import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.Json

fun loadJsonData(context: Context): List<Location> {
    val jsonString = context.assets
        .open("data/gems.json")
        .bufferedReader()
        .use { it.readText() }

    val json = Json { ignoreUnknownKeys = true }

    return json.decodeFromString(jsonString)
}

