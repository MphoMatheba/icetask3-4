package com.example.microtrip_appimport 


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext


@Composable
fun DetailScreen(location: Location) {

    val context = LocalContext.current

    Column(modifier = Modifier.padding(16.dp)) {

        AsyncImage(
            model = "file:///android_asset/images/${location.image}",
            contentDescription = location.name,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(location.name, style = MaterialTheme.typography.titleLarge)
        Text(location.description)

        Spacer(modifier = Modifier.height(16.dp))

        Text("Transport: R${location.budget.transport}")
        Text("Food: R${location.budget.food}")
        Text("Entry: R${location.budget.entry}")
        Text("Misc: R${location.budget.misc}")

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            openInGoogleMaps(context, location)
        }) {
            Text("Open in Google Maps")
        }
    }
}