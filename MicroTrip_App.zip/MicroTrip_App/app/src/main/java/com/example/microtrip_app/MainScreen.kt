package com.example.microtrip_app

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.microtrips.data.loadJsonData

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val locations = loadJsonData(context)

    Scaffold(
        topBar = { TopAppBar(title = { Text("Micro Trips") }) }
    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = "explore",
            modifier = Modifier.padding(padding)
        ) {

            composable("explore") {
                ExploreScreen(navController, locations)
            }

            composable(
                "detail/{name}",
                arguments = listOf(navArgument("name") { defaultValue = "" })
            ) { backStack ->
                val name = backStack.arguments?.getString("name") ?: ""
                val location = locations.find { it.name == name }
                if (location != null) DetailScreen(location)
            }
        }
    }
}