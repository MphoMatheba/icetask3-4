package com.example.microtrip_app.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun MicroTripsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(),
        content = content
    )
}