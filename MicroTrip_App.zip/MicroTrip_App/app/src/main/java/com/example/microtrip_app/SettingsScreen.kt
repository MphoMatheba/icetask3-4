package com.example.microtrip_app



import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*

@Composable
fun SettingsScreen() {

    var darkMode by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp)) {

        Text("Settings")

        Row {
            Text("Dark Mode")
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
                checked = darkMode,
                onCheckedChange = { darkMode = it }
            )
        }
    }
}