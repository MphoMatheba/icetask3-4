package com.example.microtrip_app



import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun SavedScreen() {
    Text("Saved screen")
}