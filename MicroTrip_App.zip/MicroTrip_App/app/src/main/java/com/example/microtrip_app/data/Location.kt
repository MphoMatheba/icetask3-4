package com.example.microtrip_app.data

data class Location(
    val name: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val image: String,
    val budget: Budget
)