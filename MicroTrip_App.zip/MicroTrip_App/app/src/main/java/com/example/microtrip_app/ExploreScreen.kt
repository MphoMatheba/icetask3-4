package com.example.microtrip_app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.microtrips.data.Location

@Composable
fun ExploreScreen(navController: NavController, locations: List<Location>) {

    LazyColumn {
        items(locations) { location ->

            Card(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate("detail/${location.name}")
                    }
            ) {

                Column(modifier = Modifier.padding(16.dp)) {

                    AsyncImage(
                        model = "file:///android_asset/images/${location.image}",
                        contentDescription = location.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(location.name, style = MaterialTheme.typography.titleMedium)
                    Text(location.description)
                }
            }
        }
    }
}